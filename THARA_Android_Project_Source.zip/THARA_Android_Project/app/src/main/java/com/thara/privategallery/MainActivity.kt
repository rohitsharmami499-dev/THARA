package com.thara.privategallery

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Initial native THARA scaffold. Encrypted-at-rest storage is implemented; LAN sync is not yet complete. */
class MainActivity : Activity() {
    private val sequence = listOf("Lion", "Bear", "Monkey", "Giraffe")
    private var progress = 0
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        val title = TextView(this).apply { text = "THARA Private Gallery"; textSize = 26f; gravity = Gravity.CENTER }
        status = TextView(this).apply { text = "Private storage is on this phone. Choose the animals in order."; textSize = 16f; gravity = Gravity.CENTER; setPadding(0, 24, 0, 24) }
        root.addView(title)
        root.addView(status)
        sequence.forEach { animal ->
            root.addView(Button(this).apply {
                text = animal
                setOnClickListener {
                    if (animal == sequence[progress]) {
                        progress++
                        if (progress == sequence.size) {
                            progress = 0
                            status.text = "Secret sequence accepted. Set up a real app lock before storing private photos."
                            Toast.makeText(this@MainActivity, "Sequence accepted", Toast.LENGTH_SHORT).show()
                        } else status.text = "Correct: ${progress}/4"
                    } else {
                        progress = 0
                        status.text = "$animal information: animal screen only. Secret gallery stays locked."
                    }
                }
            })
        }
        root.addView(Button(this).apply {
            text = "Import photo to encrypted storage"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"
                }
                @Suppress("DEPRECATION") startActivityForResult(intent, 101)
            }
        })
        root.addView(Button(this).apply {
            text = "Check encrypted storage"
            setOnClickListener {
                val count = File(filesDir, "vault").listFiles()?.size ?: 0
                status.text = "Encrypted photo files stored: $count"
            }
        })
        setContentView(root)
    }

    @Deprecated("Uses the document picker result API for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 101 || resultCode != Activity.RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            val plain = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Could not read image")
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            val encrypted = cipher.iv + cipher.doFinal(plain)
            val dir = File(filesDir, "vault").apply { mkdirs() }
            File(dir, "photo_${System.currentTimeMillis()}.thara").writeBytes(encrypted)
            status.text = "Photo encrypted and saved inside app storage. Original photo may still remain in Gallery."
        } catch (e: Exception) {
            status.text = "Import failed: ${e.message ?: "unknown error"}"
        }
    }

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    companion object { private const val KEY_ALIAS = "thara_local_aes_gcm_key_v1" }
}
